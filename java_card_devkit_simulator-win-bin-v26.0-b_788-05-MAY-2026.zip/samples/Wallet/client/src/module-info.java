/*
 * Copyright (c) 1998, 2026, Oracle and/or its affiliates.
 */
module com.oracle.javacard.sample.walletClient {
	exports com.oracle.javacard.sample;

	requires com.oracle.javacard.amservice;
	requires java.smartcardio;
}
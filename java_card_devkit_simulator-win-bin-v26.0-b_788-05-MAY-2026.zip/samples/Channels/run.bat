::
:: Copyright (c) 1998, 2026, Oracle and/or its affiliates.
::
@echo off

setlocal

:: Evaluate samples dir out of current directory (parent dir)
for %%I in (.) do set SAMPLES_DIR=%%~pdI
:: Evaluate sample name out of current directory, too
for %%I in (.) do set SAMPLE_NAME=%%~nxI

set CLIENT_NAME=com.oracle.javacard.sample.AMSChannelsClient

set CAP=%SAMPLES_DIR%\%SAMPLE_NAME%\applet\deliverables\Channels\com\oracle\jcclassic\samples\channels\javacard\channels.cap
set PROPS=%JC_HOME_SIMULATOR%\samples\client.config.properties

set ARGS_CLIENT="-cap=%CAP% -props=%PROPS%"
if "%~1" NEQ "" (
    set HOST="-host=%~1"
)

pushd..
call run.bat %SAMPLE_NAME% %CLIENT_NAME% %ARGS_CLIENT% %HOST%


::
:: Copyright (c) 1998, 2026, Oracle and/or its affiliates.
::
@echo off

setlocal

for %%I in (.) do set SAMPLE_NAME=%%~nxI
set ORDER="libPackageC packageA packageB"

@echo Sample name: [%SAMPLE_NAME%]
@echo.

pushd..
call build.bat %SAMPLE_NAME% %ORDER%

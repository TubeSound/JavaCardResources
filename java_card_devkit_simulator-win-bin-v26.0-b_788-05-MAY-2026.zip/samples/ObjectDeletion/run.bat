::
:: Copyright (c) 1998, 2026, Oracle and/or its affiliates.
::
@echo off

setlocal

:: Evaluate samples dir out of current directory (parent dir)
for %%I in (.) do set SAMPLES_DIR=%%~pdI
:: Evaluate sample name out of current directory, too
for %%I in (.) do set SAMPLE_NAME=%%~nxI

set CLIENT_NAME=com.oracle.javacard.sample.ClientObjectDeletion

set CAP_A=%SAMPLES_DIR%\%SAMPLE_NAME%\applet\deliverables\packageA\com\oracle\jcclassic\samples\odsample\packageA\javacard\packageA.cap
set CAP_B=%SAMPLES_DIR%\%SAMPLE_NAME%\applet\deliverables\packageB\com\oracle\jcclassic\samples\odsample\packageB\javacard\packageB.cap
set CAP_C=%SAMPLES_DIR%\%SAMPLE_NAME%\applet\deliverables\libPackageC\com\oracle\jcclassic\samples\odsample\libPackageC\javacard\libPackageC.cap
set PROPS=%JC_HOME_SIMULATOR%\samples\client.config.properties

set ARGS_CLIENT="-capA=%CAP_A% -capB=%CAP_B% -capC=%CAP_C% -props=%PROPS%"
if "%~1" NEQ "" (
    set HOST="-host=%~1"
)

pushd..
call run.bat %SAMPLE_NAME% %CLIENT_NAME% %ARGS_CLIENT% %HOST%


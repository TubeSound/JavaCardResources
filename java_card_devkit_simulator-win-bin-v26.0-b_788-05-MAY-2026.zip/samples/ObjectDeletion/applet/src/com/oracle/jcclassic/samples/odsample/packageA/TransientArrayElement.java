/** 
 * Copyright (c) 1998, 2026, Oracle and/or its affiliates.
 * 
 */

/*
 */

package com.oracle.jcclassic.samples.odsample.packageA;

/**
 * Class represents object used as elements of transient array
 */
public class TransientArrayElement {
    public short data;

    public TransientArrayElement(short s) {
        data = s;
    }
}
